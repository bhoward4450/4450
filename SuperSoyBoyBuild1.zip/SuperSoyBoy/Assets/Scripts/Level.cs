﻿using System.Collections;
using UnityEngine;

public class Level : MonoBehaviour {
	public string levelName;
}
