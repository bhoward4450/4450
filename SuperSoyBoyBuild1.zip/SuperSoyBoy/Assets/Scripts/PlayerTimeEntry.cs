﻿using System;

[Serializable]
public class PlayerTimeEntry {
	public DateTime entryDate;
	public decimal time;
}
